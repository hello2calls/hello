mod_ipp_g729
============

Hacked FreeSWITCH-G729 speech codec using Intel® Integrated Performance Primitive.
This module enables the commericial G729 codec support for FreeSWITCH. 

This module is used for educational purposes.
